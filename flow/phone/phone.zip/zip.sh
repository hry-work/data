cp phone.flow bak1.flow
cp phone.flow bak2.flow
cp phone.flow bak3.flow
rm -f *.zip
zip phone.zip *