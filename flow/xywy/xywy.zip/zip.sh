cp xywy.flow bak1.flow
cp xywy.flow bak2.flow
cp xywy.flow bak3.flow
rm -f *.zip
zip xywy.zip *