cp every_1d@0h1m.flow bak1.flow
cp every_1d@0h1m.flow bak2.flow
cp every_1d@0h1m.flow bak3.flow
cp every_1d@0h1m.flow bak4.flow
cp every_1d@0h1m.flow bak5.flow
cp dk_30.flow bak_dk.flow
rm -f *.zip
zip aiyunxiao.zip *
